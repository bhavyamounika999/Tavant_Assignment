import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { Register } from 'src/app/auth/models/register';
import { AuthService } from 'src/app/auth/services/auth.service';
import { CreateProfileService } from 'src/app/create-profile/services/create-profile.service';
import { CreateProfile } from 'src/app/create-profile/models/create-profile';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  register: Register;
  profile: CreateProfile;
  constructor(
    private authService: AuthService,
    private createProfileService: CreateProfileService
  ) {}

  ngOnInit(): void {
    this.authService.loadUser().subscribe((res) => {
      console.log(JSON.stringify(res));
      this.register = res;

      localStorage.setItem('users', JSON.stringify(res));
    });

    this.createProfileService.getProfile().subscribe((res) => {
      console.log(JSON.stringify(res));
      this.profile = res;

      localStorage.setItem('profile', JSON.stringify(res));
    });
    (err) => console.log(err);
  }
}
