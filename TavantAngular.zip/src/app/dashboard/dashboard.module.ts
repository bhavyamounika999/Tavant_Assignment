import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { HttpClientModule } from '@angular/common/http';
import { CoreModule } from '../core/core.module';
import { AuthService } from '../auth/services/auth.service';
import { httpInterceptorProviders } from '../core/interceptors';
import { CreateProfileService } from '../create-profile/services/create-profile.service';

@NgModule({
  declarations: [DashboardComponent],
  providers: [httpInterceptorProviders, AuthService, CreateProfileService],
  imports: [CommonModule, DashboardRoutingModule, HttpClientModule, CoreModule],
})
export class DashboardModule {}
