import { CreateProfile } from './create-profile';

describe('CreateProfile', () => {
  it('should create an instance', () => {
    expect(new CreateProfile()).toBeTruthy();
  });
});
